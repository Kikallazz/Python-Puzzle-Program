import pygame as pg
import os
import cv2
pg.init()


def aspect_scale(image, bx, by):
    ix,iy = image.get_size()
    if ix > iy:
        # fit to width
        scale_factor = bx/float(ix)
        sy = scale_factor * iy
        if sy > by:
            scale_factor = by/float(iy)
            sx = scale_factor * ix
            sy = by
        else:
            sx = bx
    else:
        # fit to height
        scale_factor = by/float(iy)
        sx = scale_factor * ix
        if sx > bx:
            scale_factor = bx/float(ix)
            sx = bx
            sy = scale_factor * iy
        else:
            sy = by

    return pg.transform.scale(image, (int(sx),int(sy)))


WIN_WIDTH = 600
WIN_HEIGHT = 700
HALF_WIDTH = int(WIN_WIDTH / 2)
HALF_HEIGHT = int(WIN_HEIGHT / 2)

DISPLAY = (WIN_WIDTH, WIN_HEIGHT)
DEPTH = 32
FLAGS = 0
timer = pg.time.Clock()
timer.tick(144)

image1 = pg.image.load('cropper_test\\raw\\test.jpg')
imw, imh = image1.get_rect().size
print(imw if imw > imh else imh)
image1 = aspect_scale(image1, 50, 50)


screen = pg.display.set_mode(DISPLAY, FLAGS, DEPTH)
pg.display.set_caption("")

black = (0, 0, 0)
white = (255, 255, 255)
red = (200, 0, 0)
green = (0, 200, 0)
blue = (0, 0, 255)

background = (235, 245, 220)
redl = (245, 10, 10)
redlp = (255, 75, 75)


def main():
    global timer
    files = []
    for i in os.listdir(os.getcwd()+'\images\pieces'):
        files.append(i)

    objs = []
    for filename in files:
            if '.jpg' in filename:
                thumb = pg.image.load('images\pieces\\'+filename)
                imw, imh = thumb.get_rect().size
                thumb = aspect_scale(thumb, 50, 50)
                focus = False
                objs.append(obj_button(filename, HALF_WIDTH-100, ((60)*((files.index(filename))+1)), 200, 50, redl, redlp, thumb, focus))

    while True:
        timer.tick(144)
        click = 0
        mouse = pg.mouse.get_pos()
        screen.fill(background)

        for e in pg.event.get():
            if e.type == pg.QUIT:
                raise(SystemExit, "QUIT")
            if e.type == pg.KEYDOWN:
                if e.key == pg.K_ESCAPE:
                    quit()
                if e.key == pg.K_UP:
                    up = True
                if e.key == pg.K_DOWN:
                    down = True
                if e.key == pg.K_LEFT:
                    left = True
                if e.key == pg.K_RIGHT:
                    right = True
                if e.key == pg.K_SPACE:
                    space = True

            elif e.type == pg.KEYUP:
                if e.key == pg.K_ESCAPE:
                    quit()
                if e.key == pg.K_UP:
                    up = False
                if e.key == pg.K_DOWN:
                    down = False
                if e.key == pg.K_RIGHT:
                    right = False
                if e.key == pg.K_LEFT:
                    left = False
                if e.key == pg.K_SPACE:
                    space = False

            elif e.type == pg.MOUSEBUTTONDOWN:
                click = mouse

        for obj in objs:
            obj.check_select(click)
            obj.show(mouse)
            
        pg.display.update()

def file_select(word, x, y):
    f_s = True

    print(word)
    screen.fill((255, 255, 255))
    button('you clicked', x, y, 200, 200, red, blue)
    pg.display.update()

class obj_button:
    
    def __init__(self, txt, x, y, w, h, ic, ac, img, focus):
        self.txt = txt
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.ic = ic
        self.ac = ac
        self.img = img
        self.focus = focus

    def show(self, mouse):

        if self.x+self.w > mouse[0] > self.x-self.img.get_size()[0] and self.y+self.h > mouse[1] > self.y:
            pg.draw.rect(screen, black, (self.x-54, self.y-2, self.w+56, self.h+4))
            pg.draw.rect(screen, self.ac, (self.x,self.y,self.w,self.h))
            pg.draw.rect(screen, white, (self.x-52,self.y,50,self.h))
            screen.blit(self.img, (self.x-self.img.get_size()[0]-2, self.y+((self.h-self.img.get_size()[1])/2)))
        else:
            pg.draw.rect(screen, black, (self.x-54, self.y-2, self.w+56, self.h+4))
            pg.draw.rect(screen, self.ic, (self.x,self.y,self.w,self.h))
            pg.draw.rect(screen, white, (self.x-52,self.y,50,self.h))
            screen.blit(self.img, (self.x-self.img.get_size()[0]-2, self.y+((self.h-self.img.get_size()[1])/2)))

        smallText = pg.font.Font('freesansbold.ttf', 20)
        textSurf, textRect = text_objects(self.txt, smallText)
        textRect.center = ((self.x+(self.w/2)), (self.y+(self.h/2)))
        screen.blit(textSurf, textRect)

    def check_select(self, click):
        if click != 0:
        if x+w > click[0] > x-img.get_size()[0] and y+h > click[1] > y:    
            pg.draw.rect(screen, green, (x-54, y-2, w+56, h+4))
            pg.draw.rect(screen, ic, (x,y,w,h))
            pg.draw.rect(screen, white, (x-52,y,50,h))
            screen.blit(img, (x-img.get_size()[0]-2, y+((h-img.get_size()[1])/2)))




def button(txt, x, y, w, h, ic, ac, img, click):
    mouse = pg.mouse.get_pos()

    if x+w > mouse[0] > x-img.get_size()[0] and y+h > mouse[1] > y:
        pg.draw.rect(screen, black, (x-54, y-2, w+56, h+4))
        pg.draw.rect(screen, ac, (x,y,w,h))
        pg.draw.rect(screen, white, (x-52,y,50,h))
        screen.blit(img, (x-img.get_size()[0]-2, y+((h-img.get_size()[1])/2)))
    else:
        pg.draw.rect(screen, black, (x-54, y-2, w+56, h+4))
        pg.draw.rect(screen, ic, (x,y,w,h))
        pg.draw.rect(screen, white, (x-52,y,50,h))
        screen.blit(img, (x-img.get_size()[0]-2, y+((h-img.get_size()[1])/2)))

    if click != 0:
        if x+w > click[0] > x-img.get_size()[0] and y+h > click[1] > y:    
            pg.draw.rect(screen, green, (x-54, y-2, w+56, h+4))
            pg.draw.rect(screen, ic, (x,y,w,h))
            pg.draw.rect(screen, white, (x-52,y,50,h))
            screen.blit(img, (x-img.get_size()[0]-2, y+((h-img.get_size()[1])/2)))
            # new_img = cv2.imread('images\pieces\\'+txt)
            # cv2.imshow('a', new_img)
            # cv2.waitKey(0) & 0xFF
            # cv2.destroyAllWindows()

    smallText = pg.font.Font('freesansbold.ttf', 20)
    textSurf, textRect = text_objects(txt, smallText)
    textRect.center = ((x+(w/2)), (y+(h/2)))
    screen.blit(textSurf, textRect)

def text_objects(text, font):
    textSurface = font.render(text, True, black)
    return textSurface, textSurface.get_rect()

if __name__ == '__main__':
    main()