import pygame as pg
import os
import cv2
pg.init()


def aspect_scale(image, bx, by):
    ix,iy = image.get_size()
    if ix > iy:
        # fit to width
        scale_factor = bx/float(ix)
        sy = scale_factor * iy
        if sy > by:
            scale_factor = by/float(iy)
            sx = scale_factor * ix
            sy = by
        else:
            sx = bx
    else:
        # fit to height
        scale_factor = by/float(iy)
        sx = scale_factor * ix
        if sx > bx:
            scale_factor = bx/float(ix)
            sx = bx
            sy = scale_factor * iy
        else:
            sy = by

    return pg.transform.scale(image, (int(sx),int(sy)))


WIN_WIDTH = 600
WIN_HEIGHT = 700
HALF_WIDTH = int(WIN_WIDTH / 2)
HALF_HEIGHT = int(WIN_HEIGHT / 2)

DISPLAY = (WIN_WIDTH, WIN_HEIGHT)
DEPTH = 32
FLAGS = 0
timer = pg.time.Clock()
timer.tick(144)

image1 = pg.image.load('cropper_test\\raw\\test.jpg')
imw, imh = image1.get_rect().size
print(imw if imw > imh else imh)
image1 = aspect_scale(image1, 50, 50)


screen = pg.display.set_mode(DISPLAY, FLAGS, DEPTH)
pg.display.set_caption("")

black = (0, 0, 0)
white = (255, 255, 255)
red = (200, 0, 0)
green = (0, 200, 0)
blue = (0, 0, 255)
overlay = (215, 220, 200)

background = (235, 245, 220)
button_back = (255, 105, 97)
button_backlp = (255, 134, 128)


def main():
    global timer
    files = []
    for i in os.listdir(os.getcwd()+'\images\pieces'):
        files.append(i)

    objs = []
    for filename in files:
            if '.jpg' in filename:
                but_size = (WIN_WIDTH/2-WIN_WIDTH/10, 60)
                filepath = os.getcwd()+'images\pieces\\'
                thumb = pg.image.load('images\pieces\\'+filename)
                imw, imh = thumb.get_rect().size
                thumb = aspect_scale(thumb, but_size[1], but_size[1])
                thumb_width = thumb_height = but_size[1]
                focus = False
                objs.append(obj_button(filename, filepath, HALF_WIDTH-but_size[0]/2+25, ((but_size[1]+15)*((files.index(filename))+1)), but_size[0], but_size[1], button_back, button_backlp, thumb, thumb_width, thumb_height, focus))

    while True:
        timer.tick(144)
        click = 0
        mouse = pg.mouse.get_pos()
        screen.fill(background)

        for e in pg.event.get():
            if e.type == pg.QUIT:
                raise(SystemExit, "QUIT")
            if e.type == pg.KEYDOWN:
                if e.key == pg.K_ESCAPE:
                    quit()
                if e.key == pg.K_UP:
                    up = True
                if e.key == pg.K_DOWN:
                    down = True
                if e.key == pg.K_LEFT:
                    left = True
                if e.key == pg.K_RIGHT:
                    right = True
                if e.key == pg.K_SPACE:
                    space = True

            elif e.type == pg.KEYUP:
                if e.key == pg.K_ESCAPE:
                    quit()
                if e.key == pg.K_UP:
                    up = False
                if e.key == pg.K_DOWN:
                    down = False
                if e.key == pg.K_RIGHT:
                    right = False
                if e.key == pg.K_LEFT:
                    left = False
                if e.key == pg.K_SPACE:
                    space = False

            elif e.type == pg.MOUSEBUTTONDOWN:
                click = mouse

        for obj in objs:
            obj.check_select(click)
            obj.show(mouse)
        
        pg.display.update()


class obj_button:
    
    def __init__(self, txt, filepath, x, y, w, h, ic, ac, img, img_w, img_h, focus):
        self.txt = txt
        self.filepath = filepath
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.ic = ic
        self.ac = ac
        self.img = img
        self.img_w = img_w
        self.img_h = img_h
        self.focus = focus
        self.final_txts = 0
        self.in_dim = 0

    def show(self, mouse):

        if self.x+self.w > mouse[0] > self.x-self.img.get_size()[0] and self.y+self.h > mouse[1] > self.y:
            if self.focus:
                pg.draw.rect(screen, green, (self.x-self.img_w-6, self.y-3, self.w+self.img_w+9, self.h+6))
                pg.draw.rect(screen, self.ac, (self.x,self.y,self.w,self.h))
                pg.draw.rect(screen, white, (self.x-self.img_w-3,self.y,self.img_w,self.h))
                s = pg.Surface((self.w, self.in_dim))
                s.set_alpha(180)
                s.fill(overlay)
                screen.blit(s, (self.x,self.y+self.h-self.in_dim))
                screen.blit(self.img, (self.x-self.img.get_size()[0]-3, self.y+((self.h-self.img.get_size()[1])/2)))
            else:
                pg.draw.rect(screen, black, (self.x-self.img_w-4, self.y-2, self.w+self.img_w+6, self.h+4))
                pg.draw.rect(screen, self.ac, (self.x,self.y,self.w,self.h))
                pg.draw.rect(screen, white, (self.x-self.img_w-2,self.y,self.img_w,self.h))
                s = pg.Surface((self.w, self.in_dim))
                s.set_alpha(180)
                s.fill(overlay)
                screen.blit(s, (self.x,self.y+self.h-self.in_dim))
                screen.blit(self.img, (self.x-self.img.get_size()[0]-2, self.y+((self.h-self.img.get_size()[1])/2)))
        else:
            if self.focus:
                pg.draw.rect(screen, green, (self.x-self.img_w-6, self.y-3, self.w+self.img_w+9, self.h+6))
                pg.draw.rect(screen, self.ic, (self.x,self.y,self.w,self.h))
                pg.draw.rect(screen, white, (self.x-self.img_w-3,self.y,self.img_w,self.h))
                s = pg.Surface((self.w, self.in_dim))
                s.set_alpha(180)
                s.fill(overlay)
                screen.blit(s, (self.x,self.y+self.h-self.in_dim))
                screen.blit(self.img, (self.x-self.img.get_size()[0]-3, self.y+((self.h-self.img.get_size()[1])/2)))
            else:
                pg.draw.rect(screen, black, (self.x-self.img_w-4, self.y-2, self.w+self.img_w+6, self.h+4))
                pg.draw.rect(screen, self.ic, (self.x,self.y,self.w,self.h))
                pg.draw.rect(screen, white, (self.x-self.img_w-2,self.y,self.img_w,self.h))
                s = pg.Surface((self.w, self.in_dim))
                s.set_alpha(180)
                s.fill(overlay)
                screen.blit(s, (self.x,self.y+self.h-self.in_dim))
                screen.blit(self.img, (self.x-self.img.get_size()[0]-2, self.y+((self.h-self.img.get_size()[1])/2)))

        smallText = pg.font.Font('freesansbold.ttf', 20)
        textSurf, textRect = text_objects(self.txt, smallText)
        textRect.center = ((self.x+(self.w/2)), (self.y+(self.h/2)-self.in_dim/2))
        screen.blit(textSurf, textRect)

        text_size = 20
        smallerText = pg.font.Font('freesansbold.ttf', text_size)
        textSurf, textRect = text_objects(self.filepath, smallerText)
        if textRect.width >= self.w:
            if self.final_txts == 0:
                sizing = True
            else:
                text_size = self.final_txts
                smallerText = pg.font.Font('freesansbold.ttf', text_size)
                textSurf, textRect = text_objects(self.filepath, smallerText)
                sizing = False
        while sizing:
            print(text_size)
            if textRect.width >= self.w:
                text_size -= 1
                smallerText = pg.font.Font('freesansbold.ttf', text_size)
                textSurf, textRect = text_objects(self.filepath, smallerText)
            else:
                self.final_txts = text_size
                sizing = False
        self.in_dim = text_size+2
        textRect.center = (self.x+self.w/2, self.y+self.h-text_size/2-1)
        screen.blit(textSurf, textRect)

    def check_select(self, click):
        if click != 0:
            if not self.focus:
                if self.x+self.w > click[0] > self.x-self.img.get_size()[0] and self.y+self.h > click[1] > self.y:
                    self.focus = True
                    return
                else:
                    self.focus = False
                    return
            else:
                if self.x+self.w > click[0] > self.x-self.img.get_size()[0] and self.y+self.h > click[1] > self.y:
                    self.focus = False
                    return
                else:
                    self.focus = True
                    return


def text_objects(text, font):
    textSurface = font.render(text, True, black)
    return textSurface, textSurface.get_rect()

if __name__ == '__main__':
    main()